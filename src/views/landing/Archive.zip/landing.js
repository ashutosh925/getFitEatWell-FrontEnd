import React from "react"
import Banners from './Banner/banner';
import Services  from './Services/services';
// import Footer from './LandingFooter';
// css
import "./assets/themify-icon/themify-icons.css";
import "./assets/simple-line-icon/simple-line-icons.css";
import "./assets/font-awesome/css/all.css";
import "./assets/elagent/style.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./assets/animate.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./assets/main.css";
import "./assets/responsive.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "popper.js";


class LandingPage extends React.Component {
  render() {
    return (
      <div className="body_wrapper">
      {/* <Banners/> */}
      <Services/>
      {/* <Footer/> */}
      </div>
    )
  }
}

// export const Home = () => (
//     <div className="body_wrapper">
//         {/* <CustomNavbar cClass="custom_container p0" hbtnClass="new_btn"/> */}
//         {/* <DesignBanner/> */}
//         <Service/>
//         {/* <Subscribe FooterData={FooterData}/>
//         <Footer FooterData={FooterData}/> */}
//     </div>
// )

export default LandingPage
